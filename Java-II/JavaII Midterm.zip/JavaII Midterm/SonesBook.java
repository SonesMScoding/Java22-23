abstract class SonesBook{

    protected String title;
    protected Double price;

    public String toString(){
        return "Title: " + title + ".....Price:$" + price;
    }


    public SonesBook(String bookTitle){
        title = bookTitle;
    }
 
    public Double getPrice(){
        return price;
    }

    public String getTitle(){
        return title;
    }

    public abstract void setPrice(double price);



public static void main(String[] args) {

}

}