public class SonesNonFiction extends SonesBook {
    //subclass

    public SonesNonFiction(String title, double price){
        super(title);
        setPrice(price);
    }

     public void setPrice(double price) {
        super.price = price;
    }

    public String getCategory(String category){
        return category;
    }

}

    

//demo object
// SonesNonfiction snf = new SonesNonfiction("", 1209, "");
//snf.display(); <- how to use the display method