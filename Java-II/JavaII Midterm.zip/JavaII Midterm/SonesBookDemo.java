import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class SonesBookDemo 
{
    public static void main(String[] args) {
        Path file = 
            Paths.get("C:\\Users\\heyoi\\OneDrive - prcc.edu\\Desktop\\JavaII\\JavaII Midterm\\books.txt");
        String str;
        String delimeter =",";
        String title;
        String sprice;
        double price;
        String category;
        int len;

    
        try{
            InputStream input = 
            new BufferedInputStream(Files.newInputStream(file));

            BufferedReader reader = 
            new BufferedReader(new InputStreamReader(input));

            str = reader.readLine();

            while(str != null)
            {
                title = str.substring(0, str.indexOf(delimeter,0));
                len = title.length();
                sprice= str.substring(len+1, str.indexOf(delimeter, len+1));
                price = Double.parseDouble(sprice);
                len = len + sprice.length() +2;
                category = str.substring(len);



                if(category == "Fiction"){
                    SonesBook [] sfBooks = { 
                        new SonesFiction(title, price)};
                }
                else
                {
                    SonesBook [] snfBooks = {
                        new SonesNonFiction(title, price)};
                }

                str = reader.readLine();
            }
                reader.close();

                displayBook(snfBooks[]);
            }
            catch(Exception e)
            {
                System.out.println("Error: " +e);
            }

        }    




public static void displayNFBook(SonesBook [] sBooks){

    if(sBooks.getCategory != "Fiction"){
        System.out.println("\nNonFiction Book\n======================");
    }
    else{
        System.out.println("\nFiction Book\n======================");
    }
    for( int i = 0; i< sBooks.length ; i++){
        System.out.println(sBooks[i].toString());
    }
}   

}

