Author: Sones
Date: 04/13/2023

SonesStringSort [X] 
notes:
-no notes should be good. has a yellow because of the lack of close input. 

SonesBookAuthor [X]
notes: 
-  There should be no issues; the program displays the 2d array, asks the user for the first 3 in the authors name
as suggested in the text starting on line 32. 
-case sensitive

SonesCustomer / SonesNine2 [partial]
notes: 
- Worked all day friday, didn't get the last 45 points, but it will be okay.