public class SonesFiction extends SonesBook {
    //subclass

        public SonesFiction(String title, double price){
            super(title);
            setPrice(price);
        }
    
         public void setPrice(double price) {
            super.price = price;}
    
        }